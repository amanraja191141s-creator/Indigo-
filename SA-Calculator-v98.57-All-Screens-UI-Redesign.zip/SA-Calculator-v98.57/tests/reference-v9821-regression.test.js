const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const css = fs.readFileSync(path.join(root, 'assets/css/app.css'), 'utf8');
const js = fs.readFileSync(path.join(root, 'assets/js/app.js'), 'utf8');
test('v98.21 keypad matches reference row order and contains AC/sign/zero-span controls', () => {
  const keypad = html.match(/<div class="main-keypad"[\s\S]*?<\/div>/)?.[0] || '';
  const actions = [...keypad.matchAll(/data-calc="([^"]+)"/g)].map(m => m[1]);
  assert.deepEqual(actions, ['C','±','%','/','7','8','9','*','4','5','6','-','1','2','3','+','0','.','=']);
  assert.match(keypad, /aria-label="All clear">AC/);
  assert.match(keypad, /class="key-btn zero-key"/);
  assert.match(js, /if\(action==='±'\)/);
});
test('v98.21 forces all calculator keys to fill grid cells and corrects the Android focus-link overlay', () => {
  assert.match(css, /#screen-calc \.main-keypad \.key-btn \{[^}]*width:100% !important;[^}]*height:100% !important;/s);
  assert.match(css, /\.skip-to-workspace:focus:not\(:focus-visible\)/);
  assert.match(css, /body\.tool-screen-active header\.app-header \{ display:none !important;/);
});
test('v98.21 keeps scientific functions, history and memory controls accessible outside the compact keypad', () => {
  assert.match(html, /id="screen-scientific"/);
  assert.match(html, /id="btn-history-open"/);
  const sci = html.slice(html.indexOf('id="screen-scientific"'), html.indexOf('id="screen-currencies"'));
  assert.match(sci, /class="scientific-memory-row"/);
  assert.doesNotMatch(html.slice(html.indexOf('id="screen-calc"'), html.indexOf('id="screen-scientific"')), /data-sci-memory|data-memory/);
  assert.match(sci, /data-sci-action="ans"/);
  assert.match(sci, /data-sci-insert="\("/);
  assert.match(sci, /data-sci-insert="\)"/);
});

test('v98.44 replaces categorized drawer headings with the dedicated premium Tools screen', () => {
  assert.match(html, /id="screen-tools"/);
  assert.match(html, /id="premium-tools-grid"/);
  assert.match(html, /id="tools-screen-search"/);
  const drawer = html.slice(html.indexOf('id="sidebar-drawer"'), html.indexOf('</aside>'));
  assert.doesNotMatch(drawer, /Quick access|All tools|CONVERTERS|EVERYDAY CALCULATORS|drawer-category/);
  assert.match(js, /switchScreen\('tools'\)/);
  assert.match(js, /reference-screen-toolbar/);
});

test('v98.21 returns drawer focus to the visible Tools tab instead of the hidden hamburger', () => {
  assert.match(js, /const returnFocus = document\.querySelector\('\[data-bottom-nav="tools"\]'\) \|\| btnOpen/);
  assert.match(js, /const opener = document\.querySelector\('\[data-bottom-nav="tools"\]'\) \|\| document\.getElementById\('btn-drawer-open'\)/);
});

test('calculator +/- toggles the active operand without corrupting operators or scientific exponents', () => {
  const match = js.match(/function calculatorSignToggleEdit\([\s\S]*?\n\}/);
  assert.ok(match, 'sign-toggle edit helper is present');
  const helper = vm.runInNewContext(`${match[0]}; calculatorSignToggleEdit`);
  assert.deepEqual(JSON.parse(JSON.stringify(helper('123',3,3))), {start:0,end:3,text:'−123'});
  assert.deepEqual(JSON.parse(JSON.stringify(helper('−123',4,4))), {start:0,end:4,text:'123'});
  assert.deepEqual(JSON.parse(JSON.stringify(helper('5−3',3,3))), {start:2,end:3,text:'−3'});
  assert.deepEqual(JSON.parse(JSON.stringify(helper('5+−3',4,4))), {start:2,end:4,text:'3'});
  assert.deepEqual(JSON.parse(JSON.stringify(helper('2e-5',4,4))), {start:0,end:4,text:'−2e-5'});
  assert.deepEqual(JSON.parse(JSON.stringify(helper('',0,0))), {start:0,end:0,text:'−'});
});

test('v98.21 hides touch-focused skip link without disabling keyboard accessibility', () => {
  assert.match(css, /@media \(hover: none\) and \(pointer: coarse\)[\s\S]*?\.skip-to-workspace:focus[\s\S]*?pointer-events: none/s);
  assert.match(css, /\.skip-to-workspace:focus-visible/);
});

test('v98.21 source version is stamped in app metadata and service-worker cache', () => {
  const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
  const manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.webmanifest'), 'utf8'));
  assert.equal(pkg.version, '1.98.57-v98.57');
  assert.equal(manifest.version, pkg.version);
  assert.ok(html.includes(pkg.version));
  assert.ok(js.includes(pkg.version));
  assert.match(fs.readFileSync(path.join(root, 'service-worker.js'), 'utf8'), /sa-calculator-v98-57-all-screens-ui-redesign-v9857/);
});

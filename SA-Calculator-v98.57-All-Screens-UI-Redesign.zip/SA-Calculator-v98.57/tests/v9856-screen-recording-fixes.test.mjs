import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');

test('v98.56 currency picker uses the actual option currency code for its flag', () => {
  const js = read('assets/js/app.js');
  assert.match(js, /const code = String\(option\.value \|\| ''\)\.toUpperCase\(\);/);
  assert.match(js, /flag\.textContent = currencyFlagForCode\(code\);/);
  assert.doesNotMatch(js, /currencyFlagForCode\(item\.code\)/);
});

test('v98.56 app shell tracks Android visible viewport while keyboard opens', () => {
  const js = read('assets/js/app.js');
  const css = read('assets/css/rebuild-v98.56.css');
  assert.match(js, /window\.visualViewport/);
  assert.match(js, /--sa-visible-viewport-height/);
  assert.match(css, /#app-container\{height:var\(--sa-visible-viewport-height,100dvh\)!important/);
});

test('v98.56 tools list is the scroll container beneath persistent search controls', () => {
  const css = read('assets/css/rebuild-v98.56.css');
  assert.match(css, /#screen-tools \.premium-tools-grid\{[^}]*overflow-y:auto/s);
  assert.match(css, /#screen-tools \.premium-tools-grid\{[^}]*min-height:0/s);
});

test('v98.56 scientific calculator follows app dark and light themes', () => {
  const css = read('assets/css/rebuild-v98.56.css');
  assert.match(css, /#screen-scientific \.scientific-display/);
  assert.match(css, /body\[data-theme="light"\] #screen-scientific \.scientific-display/);
  assert.match(css, /#screen-scientific \.scientific-keypad button/);
});

test('v98.57 build manifest, runtime, stylesheet list and service worker agree', () => {
  const pkg = JSON.parse(read('package.json'));
  const html = read('index.html');
  const app = read('assets/js/app.js');
  const builder = read('scripts/prepare-android-web.mjs');
  const sw = read('service-worker.js');
  assert.equal(pkg.version, '1.98.57-v98.57');
  assert.match(html, /1\.98\.57-v98\.57/);
  assert.match(html, /assets\/css\/rebuild-v98\.57\.css/);
  assert.match(app, /APP_VERSION = '1\.98\.57-v98\.57'/);
  assert.match(builder, /assets\/css\/rebuild-v98\.57\.css/);
  assert.match(sw, /v98-57/);
});

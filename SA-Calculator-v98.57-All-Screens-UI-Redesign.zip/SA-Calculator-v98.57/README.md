# SA Calculator v98.57 — Screen Recording Fix Release

This release is based on the supplied 18 November 2026 Android screen recording and the v98.55 source project.

## Fixes
- Currency picker flags now use the selected option's actual ISO currency code (fixes the undefined `item.code` lookup).
- The app shell tracks Android's visible viewport so the software keyboard does not leave the fixed workspace behind the IME.
- Tool search remains in the fixed header area while the tool-card list is independently scrollable.
- Scientific Calculator uses the app's premium blue/ink palette in dark mode and a coordinated light palette, without changing calculation handlers.

## Build
- Package: `1.98.57-v98.57`
- Run `npm test` and `npm run build:web`.
- GitHub Actions workflow: `.github/workflows/main.yml` (use the supplied v98.57 workflow file).

Physical Android keyboard behavior, APK installation, and device performance still require a real Android device/build runner.

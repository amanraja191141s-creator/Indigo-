# v98.54 — Approved Neon Home replacement

- Replaced the previous Home CSS layer instead of stacking another Home override.
- Added a borderless expression/result display and scalable neon-blue wave artwork.
- Added a dedicated sharp vector SA Calculator logo with `+ − × ÷` symbols.
- Refined header controls, four-by-five keypad proportions, blue action keys and five-tab neon navigation.
- Kept the original calculator `data-calc` handlers and existing navigation event IDs.
- Added compact-width, short-height and landscape fallbacks.
- Updated the offline cache namespace, package version, manifest, Android workflow and regression suite.

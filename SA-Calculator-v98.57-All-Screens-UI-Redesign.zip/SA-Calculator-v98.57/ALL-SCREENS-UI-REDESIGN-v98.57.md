# SA Calculator v98.57 — All-screen UI redesign

## Scope
A full visual-system pass across the existing application, based on the supplied Android screen recording and the 22-app benchmark in `RESEARCH-20-PLUS-ANDROID-CALCULATOR-APPS-v98.41.md`. This is an original design system; competitor apps are UX references, not copied assets or layouts.

## Screens covered
- Main calculator and expression/result display
- Scientific calculator, editing strip, function bank, history and More panels
- Tools landing, search, category filters and tool cards
- Favorites
- Settings, theme picker and preference controls
- Calculation history overlay, row actions and scientific history/More panels
- Currency converter, rate status, currency picker and numeric dock
- Unit converter, category/unit selectors and numeric dock
- Discount, percentage, sales tax, loan, savings, tip and unit-price tools
- Body metrics, date calculator, fuel cost, fuel efficiency, GPA, hexadecimal and world time

The application DOM and business logic remain in place. This release adds a final CSS design layer and includes it in the Android web bundle build list. It does not claim to add engines or features that were not already implemented.

## Design system
- Deep navy layered surfaces with a blue/cyan action accent and restrained green status accent.
- One typography hierarchy, consistent 12–18dp corner radii, 4/8/12/16dp spacing rhythm and 48dp minimum interactive targets.
- Shared input, select, result, card, button, category-chip and modal styling.
- Dedicated scientific keypad treatment rather than forcing it into standard calculator styling.
- Converter selectors remain distinct from numeric input; currency metadata and refresh status retain their separate roles.
- Fixed bottom navigation and scrollable screen content preserve safe-area boundaries.
- Dark and light appearance palettes are explicitly supported; reduced-motion preference is respected; focus-visible states are retained.

## Verification boundary
Source tests, CSS parsing/build, JavaScript syntax, YAML parsing, ZIP integrity and screen inventory coverage are checked in CI. Physical-device visual matching, APK installation, accessibility audit with TalkBack, and frame-time measurements require an Android device/runner and are not claimed by source-only checks.

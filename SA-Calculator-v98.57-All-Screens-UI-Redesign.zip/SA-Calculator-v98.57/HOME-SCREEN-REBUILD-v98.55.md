# SA Calculator v98.55 — reference-proportional Home keypad rebuild

## Reference measurement
The supplied Neon Blue reference is 852×1846 px. Using the 2× CSS-pixel reference scale, the app content is approximately 426 CSS px wide. The four-column keys measure about 97–98 CSS px wide and 87–88 CSS px high, with roughly 6–7 CSS px horizontal/vertical gaps and a 7–8 CSS px outer inset.

## New geometry model
- The keypad is no longer `flex: 1` with five `1fr` rows that stretch to fill arbitrary leftover height.
- Key row height is `20.55cqw`, relative to the actual app width.
- Keypad block size is `102.75cqw + 33px` at standard width and `102.75cqw + 28px` at compact width; this accounts for five rows, four gaps and top inset.
- Standard key gap is `clamp(5px, 1.5cqw, 6.5px)`.
- Standard side inset is `clamp(7px, 1.8cqw, 8px)`; bottom inset is zero to match the reference's final row/nav boundary.
- Key radius is `4.5cqw`, keeping the shape proportional across phone widths.
- Key typography scales by app width: numeric 8.4cqw, utility 8.6cqw, AC 9.5cqw, operators 10.2cqw, equals 10.5cqw, with safe clamps.
- Buttons retain `min-width` and `min-height` of 48 CSS px; supported phone widths keep the rendered keys larger than this accessibility floor.

## Reference width calculations
- 426 CSS px app width: 5 rows × 87.54px; expected button width approximately 97.9px; row/column ratio approximately 1.12.
- 354 CSS px app width: 5 rows × 72.75px; expected button width approximately 81px; row/column ratio approximately 1.11.

## Behavior preserved
All original 19 `data-calc` attributes, event handlers, numeric precedence, percent/sign logic, clear, decimal, equals, and zero's two-column span are preserved. Header, expression/result display, five-tab navigation, and tool screens are not replaced by this keypad-only sizing correction.

## Verification boundary
Automated source/regression tests, CSS parsing, generated web bundle checks, workflow YAML parsing and ZIP integrity are run. Physical Android screenshot matching, installation, hosted Gradle APK build, and measured frame-time/memory performance are not claimed unless performed on a real device/runner.
